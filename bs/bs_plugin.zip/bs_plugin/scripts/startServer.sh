#!/bin/bash


echo "Starting the application server on $1"
