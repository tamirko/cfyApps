#!/bin/bash


echo "Add $1 to the FireWall"
