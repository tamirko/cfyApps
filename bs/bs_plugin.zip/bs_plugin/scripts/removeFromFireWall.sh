#!/bin/bash


echo "Remove $1 from the FireWall"
