#!/bin/bash

MANAGER_IP=`ctx node properties public_ip`
SSH_CONN=${ssh_user}@${MANAGER_IP}
SSH_EXTRA="-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"

if [ -n "${openstack_config_file}" ]; then
    ctx logger info "Copying OpenStack configuration JSON: ${openstack_config_file} -> ${SSH_CONN}"
    scp -i ${ssh_key} ${SSH_EXTRA} ${openstack_config_file} ${SSH_CONN}:~/openstack_config.json
    ssh -i ${ssh_key} -t ${SSH_EXTRA} ${SSH_CONN} "sudo mkdir -p /etc/cloudify/openstack_plugin"
    ssh -i ${ssh_key} -t ${SSH_EXTRA} ${SSH_CONN} "sudo mv ~/openstack_config.json /etc/cloudify/openstack_plugin/"
else
    ctx logger info "No OpenStack configuration JSON provided; skipping"
fi

if [ -n "${aws_config_file}" ]; then
    ctx logger info "Copying AWS configuration boto: ${aws_config_file} -> ${SSH_CONN}"
    scp -i ${ssh_key} ${SSH_EXTRA} ${aws_config_file} ${SSH_CONN}:~/boto
    ssh -i ${ssh_key} -t ${SSH_EXTRA} ${SSH_CONN} "sudo mkdir -p /etc/cloudify/aws_plugin"
    ssh -i ${ssh_key} -t ${SSH_EXTRA} ${SSH_CONN} "sudo mv ~/boto /etc/cloudify/aws_plugin/"
else
    ctx logger info "No AWS configuration boto provided; skipping"
fi

if [ -n "${agents_key_path}" ]; then
    ctx logger info "Copying key: ${agents_key_path} -> ${SSH_CONN}:/root/.ssh/agent_key.pem"
    scp -i ${ssh_key} ${SSH_EXTRA} ${agents_key_path} ${SSH_CONN}:~/agent_key.pem
    ssh -i ${ssh_key} -t ${SSH_EXTRA} ${SSH_CONN} "sudo mv ~/agent_key.pem /root/.ssh/ && sudo chown root:root /root/.ssh/agent_key.pem"
else
    ctx logger info "No agent key path provided; skipping"
fi

ctx logger info "Configuration done."


 #scp -i ~/.ssh/aws/aws-manager-kp-usw.pem -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no resources/openstack_plugin/openstack_config.json ec2-user@54.193.208.149:~/openstack_config.json



