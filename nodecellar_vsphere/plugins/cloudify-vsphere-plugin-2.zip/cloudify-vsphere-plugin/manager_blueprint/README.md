Manager blueprint moved to https://github.com/cloudify-cosmo/cloudify-manager-blueprints/

Please use as manager blueprint such file: vsphere-manager-blueprint.yaml

Inputs example here: vsphere-manager-blueprint-inputs.yaml
